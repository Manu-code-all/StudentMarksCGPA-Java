package utils;

public class Validator {
    public static boolean isValidMark(int mark) {
        return mark >= 0 && mark <= 100;
    }

    public static boolean isValidAdmissionNo(String admissionNo) {
        return admissionNo.matches("\\d{5,10}");
    }
}

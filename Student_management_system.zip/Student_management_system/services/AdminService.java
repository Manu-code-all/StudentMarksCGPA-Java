package services;

import utils.Validator;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class AdminService {
    private Scanner scanner = new Scanner(System.in);

    public void enterStudentData() {
        System.out.print("Enter Student Name: ");
        String name = scanner.nextLine();

        System.out.print("Enter Admission Number: ");
        String admissionNo = scanner.nextLine();

        if (!Validator.isValidAdmissionNo(admissionNo)) {
            System.out.println("Invalid Admission Number!");
            return;
        }

        int[] marks = new int[5];
        for (int i = 0; i < 5; i++) {
            System.out.print("Enter marks for Subject " + (i + 1) + ": ");
            int mark = scanner.nextInt();
            if (!Validator.isValidMark(mark)) {
                System.out.println("Invalid mark entered. Try again.");
                i--; // repeat input
            } else {
                marks[i] = mark;
            }
        }

        try {
            FileWriter fw = new FileWriter("data/students.txt", true);
            fw.write(name + "," + admissionNo);
            for (int m : marks) fw.write("," + m);
            fw.write("\n");
            fw.close();
            System.out.println("Student data saved successfully!");
        } catch (IOException e) {
            System.out.println("Error writing to file.");
        }
    }
}

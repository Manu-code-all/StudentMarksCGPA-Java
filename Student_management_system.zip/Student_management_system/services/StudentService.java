package services;

import models.Marksheet;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class StudentService {
    private Scanner scanner = new Scanner(System.in);

    public void viewMarksheet() {
        System.out.print("Enter your Admission Number: ");
        String admissionNo = scanner.nextLine();

        try (BufferedReader br = new BufferedReader(new FileReader("data/students.txt"))) {
            String line;
            boolean found = false;

            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");

                // Skip lines that don't have the correct number of fields
                if (parts.length < 7) {
                    continue;
                }

                if (parts[1].equals(admissionNo)) {
                    found = true;
                    System.out.println("\n===== Student Marksheet =====");
                    System.out.println("Name: " + parts[0]);
                    System.out.println("Admission No: " + parts[1]);

                    int[] marks = new int[5];
                    System.out.println("Subjects:");
                    for (int i = 0; i < 5; i++) {
                        marks[i] = Integer.parseInt(parts[i + 2]);
                        System.out.println("Subject " + (i + 1) + ": " + marks[i]);
                    }

                    Marksheet ms = new Marksheet(marks);
                    System.out.printf("\nCGPA: %.2f\n", ms.calculateCGPA());
                    System.out.println("=============================");
                    break;
                }
            }

            if (!found) {
                System.out.println("Student record not found.");
            }

        } catch (IOException e) {
            System.out.println("Error reading student file.");
        } catch (NumberFormatException e) {
            System.out.println("Invalid number format in marks. Please check your data file.");
        }
    }
}

package models;

public class Student {
    private String name;
    private String admissionNo;

    public Student(String name, String admissionNo) {
        this.name = name;
        this.admissionNo = admissionNo;
    }

    public String getName() {
        return name;
    }

    public String getAdmissionNo() {
        return admissionNo;
    }
}

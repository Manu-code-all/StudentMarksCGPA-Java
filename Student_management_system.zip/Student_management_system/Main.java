import services.AdminService;
import services.StudentService;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            AdminService adminService = new AdminService();
            StudentService studentService = new StudentService();

            while (true) {
                System.out.println("\n==== Student Marks Management ====");
                System.out.println("1. Admin - Enter Marks");
                System.out.println("2. Student - View Marksheet");
                System.out.println("3. Exit");
                System.out.print("Select an option: ");
                int choice = scanner.nextInt();
                scanner.nextLine(); // consume newline

                switch (choice) {
   case 1:
            adminService.enterStudentData();
            break;
   case 2:
            studentService.viewMarksheet();
            break;
   case 3:
            System.out.println("Goodbye!");
            System.exit(0);
            break;
   default:
            System.out.println("Invalid option.");
}

            }
        }
    }
}
